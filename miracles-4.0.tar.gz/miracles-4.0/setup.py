from setuptools import setup

setup (
    name = 'miracles' ,
    version = '4.0',
    description = 'Mathematical miracles of Quran, Al-Fatiha, facts 1-6',
    author = 'Alikhan Akhmetov',
    author_email = 'ahmetov_alihan@mail.ru',
    url = 'check-miracles-Quran.com',
    py_modules = ['miracles'],
)
